package vertiport.complex_authz

import data.vertiport.complex_authz.allow
import data.vertiport.complex_authz.deny

regras := {
	"system_status": "active",
	"blocked_pilots": [
		"did:pilot:suspenso-01",
		"did:pilot:baderneiro",
	],
	"blocked_passengers": [
		"cpf:123.456.789-00",
		"passport:AB98765",
	],
	"approved_mechanics": [
		"did:mech:senior-01",
		"did:mech:senior-02",
	],
	"trusted_issuers": [
		"did:web:anac.gov.br",
		"did:web:embraer.com",
		"did:web:faa.gov",
	],
	"required_certs": [
		"COMMERCIAL_PILOT",
		"NIGHT_FLIGHT",
		"URBAN_AIR_MOBILITY_V1",
	],
	"weather_limits": {
		"Heavy-Lift": {
			"max_wind": 60,
			"min_visibility": 200,
		},
		"Light-Sport": {
			"max_wind": 30,
			"min_visibility": 800,
		},
		"Passenger": {
			"max_wind": 45,
			"min_visibility": 500,
		},
	},
	"aircraft_database": {
		"FutureFlyer-X1": "Passenger",
		"CargoDrone-Z9": "Heavy-Lift",
		"TinyBee-S2": "Light-Sport",
	},
}

# Regra Mestra

# REGRA 1: Piloto (Blacklist)

# REGRA 2: Passageiros (Blacklist)

# REGRA 3: Mecânico (Whitelist)

# REGRA 4: Certificações (Sets)

# REGRA 5: Clima Dinâmico

# REGRA 6: Visibilidade

# --- NOVO ---
# REGRA 7: Emissor Confiável (Trusted Issuer)
# Verifica se a entidade que assinou a licença do piloto é confiável

# 1. Extrai o emissor do JSON de entrada

# 2. Verifica se NÃO está na lista de confiáveis

# Funções Auxiliares
array_contains(arr, elem) if {
	arr[_] == elem
}
